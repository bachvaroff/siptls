#!/bin/sh -x

cd libsrtp/libsrtp-1.5.4
make clean

cd ../../sofia-sip/sofia-sip-1.12.11
make clean

cd ../../janus-gateway
make clean

cd ..
chown -R fadmin:fadmin libsrtp sofia-sip janus-gateway
