#!/bin/sh -x

HOME=/home/fadmin
export HOME

/opt/bin/janus -c /etc/ssl/certs/janus-sofia.ucdev.lab.cer -k /etc/ssl/private/janus-sofia.ucdev.lab.key -b
