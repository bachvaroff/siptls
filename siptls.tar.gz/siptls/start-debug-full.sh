#!/bin/sh -x

HOME=/home/fadmin
export HOME

SOFIA_DEBUG=9
export SOFIA_DEBUG

NUA_DEBUG=9
export NUA_DEBUG

NEA_DEBUG=9
export NEA_DEBUG

IPTSEC_DEBUG=9
export IPTSEC_DEBUG

NTA_DEBUG=9
export NTA_DEBUG

TPORT_DEBUG=9
export TPORT_DEBUG

TPORT_LOG=/opt/var/log/tport.log
export TPORT_LOG

TPORT_DUMP=/opt/var/log/tport.dump
export TPORT_DUMP

SU_DEBUG=9
export SU_DEBUG

/opt/bin/janus -c /etc/ssl/certs/janus-sofia.ucdev.lab.cer -k /etc/ssl/private/janus-sofia.ucdev.lab.key -d 7 2>&1 | tee /opt/var/log/janus-stdout-stderr.log
