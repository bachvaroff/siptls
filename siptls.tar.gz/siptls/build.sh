#!/bin/sh -x

LD_RUN_PATH="/opt/lib"
export LD_RUN_PATH

cd libsrtp/libsrtp-1.5.4
make clean
./configure --prefix=/opt && make all shared_library && make install

cd ../../sofia-sip/sofia-sip-1.12.11
make clean
env CFLAGS="-g -O0 -std=c89" ./configure --prefix=/opt && make && make install

cd ../../janus-gateway
make clean
env CFLAGS="-I/opt/include" LDFLAGS="-L/opt/lib" SOFIA_CFLAGS="-I/opt/include/sofia-sip-1.12" SOFIA_LIBS="-lsofia-sip-ua" SRTP15X_CFLAGS="-I/opt/include" SRTP15X_LIBS="-lsrtp" \
	./configure --prefix=/opt --enable-data-channels=no && make && make install
#env CFLAGS="-I/opt/include" LDFLAGS="-L/opt/lib" SOFIA_CFLAGS="-I/opt/include/sofia-sip-1.12" SOFIA_LIBS="-lsofia-sip-ua" \
#	./configure --prefix=/opt --enable-libsrtp2 && make && make install
# make configs

cd ..
chown -R fadmin:fadmin libsrtp sofia-sip janus-gateway

cp start*.sh /opt/bin && chown 0:0 /opt/bin/start*.sh && chmod a+x /opt/bin/start*.sh
mkdir -p /opt/var/log
